/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./frontend/**/*.html",
    "./frontend/**/*.js",
    "./src/**/*.py" // Si usas templates en Python (opcional)
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}